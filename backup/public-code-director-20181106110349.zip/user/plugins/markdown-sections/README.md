# Markdown Sections

This Grav plugin let's you add additional markdown files to a page and make them available in your twig template as an array. This is very useful when you need to render complex components using markdown.

Usually you would assign the content for each tab to an array defined in the page's header section, which is written in `yaml` format and it is not full compatible with markdown neither with HTML. 

This plugin helps when you fall in this kind of situation. 

The full ducumentation is available at the [developer's website](http://diblas.net/plugins/add-extra-markdown-files-to-any-page)