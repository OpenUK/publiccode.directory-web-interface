# v0.9.1
## 12/13/2015

1. [](#bugfix)
    * Added markdown-sections.php due to wrong name in GPM system

# v0.9.0
## 11/26/2015

1. [](#new)
    * Plugin started
