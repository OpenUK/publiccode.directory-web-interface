<?php
namespace Grav\Common\Page\Interfaces;

/**
 * Class implements page interface.
 */
interface PageInterface
{
}
