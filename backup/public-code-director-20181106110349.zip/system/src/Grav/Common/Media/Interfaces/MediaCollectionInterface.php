<?php
namespace Grav\Common\Media\Interfaces;

/**
 * Class implements media collection interface.
 */
interface MediaCollectionInterface
{
}
