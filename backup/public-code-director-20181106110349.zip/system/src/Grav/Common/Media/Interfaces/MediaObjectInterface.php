<?php
namespace Grav\Common\Media\Interfaces;

/**
 * Class implements media object interface.
 */
interface MediaObjectInterface
{
}
