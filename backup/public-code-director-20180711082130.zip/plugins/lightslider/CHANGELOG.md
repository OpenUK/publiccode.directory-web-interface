# v1.5.3
## 04/11/2017

1. [](#bugfix)
    * Missed to update blueprint in the last release

# v1.5.2
## 03/31/2017

1. [](#bugfix)
    * Fix [#22](https://github.com/getgrav/grav-plugin-lightslider/issues/22) add basic lightslider page blueprint

# v1.5.1
## 08/09/2016

1. [](#improved)
    * Added support for Grav's autoescape twig setting
    * Added support for `unqiue_id` config option
1. [](#bugfix)
    * Fixed extra `}` character showing up above slider

# v1.5.0
## 02/05/2016

1. [](#improved)
    * Updated Lightslider to 1.1.5
1. [](#bugfix)
    * Fixed stopping the animation after a click on the slider
1. [](#new)
    * Added the `pauseOnHover` parameter

# v1.4.0
## 01/06/2016

1. [](#new)
    * Enable the auto rotation by default
1. [](#bugfix)
    * Drop a forgotten dump of the settings
    * Fixed the links in the README

# v1.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.2.4
## 02/19/2015

1. [](#improved)
    * Added reference for to load jQuery if needed

# v1.2.3
## 02/17/2015

1. [](#improved)
    * Utilized new generated unique_id to support multiple instances on the same page

