# v0.2.1
## 02/07/2015

1. [](#improved)
    * Updated README
    * Prepared for a proper initial release


# v0.2
## 29/06/2015

1. [](#bugfix)
    * Updated blueprint, license
    * Simplified returning the embedded
      content. Thanks to Sommerregen.


# v0.1
## 25/06/2015

1. [](#new)
    * ChangeLog started...
