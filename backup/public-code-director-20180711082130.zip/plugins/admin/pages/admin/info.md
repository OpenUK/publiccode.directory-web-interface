---
title: PHP Info
template: config
access:
    admin.settings: true
    admin.super: true
---
