# Gravstrap Plugin

`Gravstrap` is a [Grav](http://github.com/getgrav/grav) plugin that provides Bootstrap components as shortcodes. A shortcode is defined by a simple structure and it is added to a Grav page to render a full component like a simple button, or a more complex one like a carousel or a navbar, till a full complex module, like a portfolio.

The full ducumentation is available at the [developer's website](http://diblas.net/plugins/use-bootstrap-components-as-shortcodes-in-grav-cms)
